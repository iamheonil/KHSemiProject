package web.dao.impl;

import java.util.List;

import web.dao.face.User_detailDao;
import web.dto.User_detail;

public class User_detailDaoImpl implements User_detailDao {

	@Override
	public int selectCntuserByPw(User_detail user_detail) {
		return 0;
		
	}

	@Override
	public void insertUser_detail(User_detail user_detail) {
		
		
	}

	@Override
	public void updateUser_detail(User_detail user_detail) {
		
	}

	@Override
	public void deleteUser_detail(User_detail user_detail) {
		
	}

	@Override
	public List<User_detail> selectUser_detail() {
		
		return null;
	}

}