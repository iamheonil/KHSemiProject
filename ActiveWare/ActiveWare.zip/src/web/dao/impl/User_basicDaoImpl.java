package web.dao.impl;

import java.util.List;

import web.dao.face.User_basicDao;
import web.dto.User_basic;

public class User_basicDaoImpl implements User_basicDao {

	@Override
	public void insertUser_basic(User_basic user_basic) {
		
	}

	@Override
	public int selectCntUserByIdName(User_basic user_basic) {
		
		return 0;
	}

	@Override
	public int selectCntUserById(User_basic user_basic) {
		
		return 0;
	}

	@Override
	public User_basic selectCntFindId(User_basic user_basic) {
		
		return null;
	}

	@Override
	public void updateUser_basic(User_basic user_basic) {
		
		
	}

	@Override
	public void deleteUser_basic(User_basic user_basic) {
		
		
	}

	@Override
	public List<User_basic> selectUser_basic() {
		
		return null;
	}

}